<?php

//------------------------------::::::::::::::::::::------------------------------\\
// Dibuat oleh di PT. Pacifica Raya Technology \\
//------------------------------::::::::::::::::::::------------------------------\\

// Arahkan user ketika pertama kali membuka applikasi ke halaman login
header("location: masuk");
