<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Pengguna</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Quicksand', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            background: linear-gradient(135deg, #1E3A8A, #2563EB, #60A5FA);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 350px;
        }

        h2 {
            margin-bottom: 10px;
            font-size: 24px;
        }

        h4 {
            color: gray;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .input-group {
            display: flex;
            align-items: center;
            background: #f1f1f1;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .input-group i {
            margin-right: 10px;
            color: #555;
        }

        .input-box {
            border: none;
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 16px;
        }

        .btn {
            width: 100%;
            background: #007bff;
            color: white;
            padding: 8px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn:hover {
            background: #0056b3;
        }

        .login-link {
            margin-top: 10px;
            font-size: 14px;
        }

        .login-link a {
            color: #ffcc00;
            text-decoration: none;
            font-weight: bold;
        }
        .logo-buku {
            width: 80%;
            height: auto;
            margin-bottom: -95px;
            margin-top: -92px;
            margin-left: 12px;
        }
    </style>
</head>
<body>

<div class="container">
    <img src="assets/image/book6.png" alt="Logo Buku" class="logo-buku">
    <h2>Library Management System</h2>
    <h4>User Registration Form</h4>

    
    <form action="function/Process.php?aksi=daftar" method="POST">
        <div class="input-group">
            <i class="fa fa-user"></i>
            <input type="text" name="funame" class="input-box" placeholder="Nama Lengkap" required>
        </div>
        <div class="input-group">
            <i class="fa fa-user-circle"></i>
            <input type="text" name="uname" class="input-box" placeholder="Nama Pengguna" required>
        </div>
        <div class="input-group">
            <i class="fa fa-lock"></i>
            <input type="password" name="passw" class="input-box" placeholder="Kata Sandi" required>
        </div>
        <button type="submit" class="btn">Daftar</button>
    </form>
    <div class="social-auth-links text-center"></div>
                <p style="font-size: 11px; margin-top: 13px;">- ATAU -</p>

    <p class="login-link">Sudah punya akun? <a href="masuk">Login sekarang</a></p>
</div>

</body>
</html>
