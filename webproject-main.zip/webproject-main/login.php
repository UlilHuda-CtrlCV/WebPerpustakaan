<?php
session_start();
include "config/koneksi.php";

$sql = mysqli_query($koneksi, "SELECT * FROM identitas");
$row1 = mysqli_fetch_assoc($sql);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Masuk | <?= $row1['nama_app']; ?></title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  
    <style type="text/css">
      body, html {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow-x: hidden;
      font-family: Arial, sans-serif;
      background: linear-gradient(-45deg, #1abc9c,rgb(59, 175, 253), #9b59b6, #e74c3c);
      animation: gradient 10s ease infinite;
    }

    @keyframes gradient {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .container {
      margin: 0;
      padding: 0;
      width: 700px;
      height: 400px;
      margin: auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }


    .form-section {
      width: 50%;
      padding: 40px;
      color: white;
    }

    .form-section h1 {
      font-size: 32px;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .form-section input {
      width: 100%;
      margin: 10px 0;
      padding: 20px 25px;
      border-radius: 10px; 
      border: 1px solid #ddd; 
      outline: none;
      background-color: #f4f4f4;
      color: black;
      transition: all 0.3s ease;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .form-section input:focus {
      background-color: #fff; 
      border-color: #3498db;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    .input-group {
      position: relative;
      display: flex;
      align-items: center;
      width: 100%;
    }

    .input-group-text {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #aaa;
      font-size: 16px;
    }
    .input-group input {
      width: 100%;
      padding: 10px 10px 10px 40px;
      border-radius: 10px;
      border: 1px solid #ddd;
      outline: none;
      background: #f4f4f4;
      font-size: 16px;
    }

    .form-section button {
      width: 90%;
      padding: 8px;
      background-color:rgb(26, 129, 188);
      color: white;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s ease;
      margin-left: 12px; 
      margin-top: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .form-section button:hover {
      background-color:rgb(82, 150, 227);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }


    .form-section a {
      color: yellow;
      text-decoration: none;
      font-size: 14px;
    }

    .welcome-section {
      width: 50%;
      background: linear-gradient(135deg,rgb(26, 129, 188),rgb(22, 109, 160));
      height: 100%;
      border-radius: 0 20px 20px 0;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      color: white;
      text-align: center;
    }

    .welcome-section h2 {
      font-size: 28px;
      margin-bottom: 15px;
    }

    .welcome-section p {
      margin-bottom: 20px;
      font-size: 16px;
    }

    .welcome-section button {
      padding: 10px 20px;
      background-color: transparent;
      border: 2px solid white;
      border-radius: 5px;
      color: white;
      font-weight: bold;
      transition: 0.3s ease;
    }

    .welcome-section button:hover {
      background-color: white;
      color: #16a085;
    }
    .logo-buku {
      width: 100%;
      height: auto;
      margin-bottom: -45px;
      margin-top: -50px;
      margin-left: 12px;
    }

    </style>
</head>

<body>

    <div class="container">
        <!-- Login Form Section -->
        <div class="form-section">
        <h1 style="font-family: Cambria; margin-left: 12px;">User Login Form</h1>
            <form action="function/Process.php?aksi=masuk" method="POST">
            <div class="input-group">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" placeholder="Username" required>
                    </div>
            <div class="input-group">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                        <input type="password" name="password" placeholder="Password" required>
                    </div>
                <button type="submit" class="btn btn-primary btn-custom">Login</button>
            </form>
            <p class="forgot-password" style=" margin-top: 15px; margin-bottom: 15px; margin-left: 78px;"><a href="lupa-password">Forgot password?</a></p>
            <p class="signup-link" style=" margin-left: 42px;">New to this website? <a href="pendaftaran">Sign Up</a></p>
        </div>

        <!-- Welcome Section -->
        <div class="welcome-section">
            <img src="assets/image/tree.png" alt="Logo Buku" class="logo-buku">
            <h2 style="font-family: Cambria;">Halo, Teman!</h2>
            <p style="font-family: Cambria;">Temukan, pinjam, dan kelola buku favorit Anda dengan lebih praktis!</p>
            <button class="btn btn-outline-light btn-custom" onclick="window.location.href='pendaftaran'">SIGN UP</button>
        </div>
    </div>

</body>
</html>
