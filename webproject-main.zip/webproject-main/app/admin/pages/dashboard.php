<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper" style="background: linear-gradient(135deg,rgb(92, 218, 246), #e0f7ff, #ffffff,rgb(92, 218, 246));">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 style="font-family: 'Quicksand', sans-serif; font-weight: bold; color: #fff;">
            Dashboard
            <small>
                <script type='text/javascript'>
                    var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                    var date = new Date();
                    var day = date.getDate();
                    var month = date.getMonth();
                    var thisDay = date.getDay(),
                        thisDay = myDays[thisDay];
                    var yy = date.getFullYear();
                    document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + yy);
                </script>
            </small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="alert alert-info" style="background-color:rgb(216, 238, 240) !important; border-radius: 10px; font-size: 16px; color: black !important;">
    Selamat Datang, <?= $_SESSION['fullname']; ?> di Administrator Perpustakaan Digital🌐
</div>


        <!-- Dashboard Boxes -->
        <div class="row">
            <?php
            include "../../config/koneksi.php";
            $query_anggota = mysqli_query($koneksi, "SELECT * FROM user WHERE role = 'Anggota'");
            $row_anggota = mysqli_num_rows($query_anggota);
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box" style="background: linear-gradient(135deg,rgb(79, 205, 233),rgb(68, 122, 202)); border-radius: 15px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                    <div class="inner">
                        <h3><?= $row_anggota; ?></h3>
                        <p>Anggota</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <a href="anggota" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <?php
            $query_buku = mysqli_query($koneksi, "SELECT * FROM buku");
            $row_buku = mysqli_num_rows($query_buku);
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box" style="background: linear-gradient(135deg, #42e695, #3bb2b8); border-radius: 15px; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);">
                    <div class="inner">
                        <h3><?= $row_buku; ?></h3>
                        <p>Buku</p>
                    </div>
                    <div class="icon" style="top: 10px; right: 10px;">
                        <i class="fa fa-book"></i>
                    </div>
                    <a href="data-buku" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <?php
            $query_peminjaman = mysqli_query($koneksi, "SELECT * FROM peminjaman WHERE tanggal_peminjaman > 0");
            $row_peminjaman = mysqli_num_rows($query_peminjaman);
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box" style=" background: linear-gradient(135deg,rgb(221, 224, 71),rgb(198, 148, 39)); border-radius: 15px; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);">
                    <div class="inner">
                        <h3><?= $row_peminjaman; ?></h3>
                        <p>Peminjaman</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-sign-out"></i>
                    </div>
                    <a href="data-peminjaman" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <?php
            $query_pengembalian = mysqli_query($koneksi, "SELECT * FROM peminjaman WHERE tanggal_pengembalian > 0");
            $row_pengembalian = mysqli_num_rows($query_pengembalian);
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box" style="background: linear-gradient(135deg,rgb(230, 151, 66),rgb(184, 67, 59)); border-radius: 15px; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);">
                    <div class="inner">
                        <h3><?= $row_pengembalian; ?></h3>
                        <p>Pengembalian</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-sign-in"></i>
                    </div>
                    <a href="data-pengembalian" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="row">
            <?php
            include "../../config/koneksi.php";
            $query = mysqli_query($koneksi, "SELECT * FROM identitas");
            $row = mysqli_fetch_assoc($query);

            ?>

            <img src="../../assets/image/logo2.png" width="250px" height="130px" style="display: block; margin-left: auto; margin-right: auto; margin-top: 30px; margin-bottom: -20px;">

            <h2 class="text-center" style="font-family: Quicksand, sans-serif;"><?= $row['nama_app']; ?></h2>
            <p class="text-center">Alamat : <?= $row['alamat_app']; ?>| Email : <?= $row['email_app']; ?> | Nomor Telp : <?= $row['nomor_hp']; ?> </p>

        </div>
    </section>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const boxes = document.querySelectorAll('.small-box');
        boxes.forEach(box => {
            box.addEventListener('mouseover', () => {
                box.style.transform = 'scale(1.05)';
                box.style.transition = 'transform 0.2s ease-in-out';
            });
            box.addEventListener('mouseout', () => {
                box.style.transform = 'scale(1)';
            });
        });
    });
</script>
