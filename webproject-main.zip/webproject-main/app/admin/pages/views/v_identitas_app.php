<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 style="font-family: 'Quicksand', sans-serif; font-weight: bold;">
            Identitas Aplikasi
            <small>
                <script type='text/javascript'>
                    var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
                    var date = new Date();
                    var day = date.getDate();
                    var month = date.getMonth();
                    var thisDay = date.getDay(),
                        thisDay = myDays[thisDay];
                    var yy = date.getYear();
                    var year = (yy < 1000) ? yy + 1900 : yy;
                    document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
                    //
                </script>
            </small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Identitas Applikasi</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title" style="font-family: 'Quicksand', sans-serif; font-weight: bold;">Edit Identitas Applikasi</h3>
                    </div>
                    <!-- /.box-header -->
                    <form action="pages/function/Identitas.php?aksi=edit" method="POST" enctype="multipart/form-data">
                        <?php
                        include "../../config/koneksi.php";

                        $query = mysqli_query($koneksi, "SELECT * FROM identitas WHERE id_identitas = '1'");
                        $row = mysqli_fetch_assoc($query);
                        ?>
                        <div class="box-body">
                            <input name="id_identitas" type="hidden" value="1">
                            <div class="form-group">
                                <label for="nameApp">Nama Aplikasi</label>
                                <input type="text" class="form-control" id="nameApp" value="<?= $row['nama_app']; ?>" name="App" required>
                            </div>
                            <div class="form-group">
                                <label for="alamaT">Alamat Lengkap</label>
                                <textarea class="form-control" style="height: 80px; resize: none;" name="Alamat" required><?= $row['alamat_app']; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="emaiL">Email</label>
                                <input type="email" class="form-control" id="emaiL" value="<?= $row['email_app']; ?>" name="Email" required>
                            </div>
                            <div class="form-group">
                                <label for="telP">Nomor Telpon</label>
                                <input type="number" class="form-control" id="telP" value="<?= $row['nomor_hp']; ?>" name="Telp" required>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-block btn-primary">Update</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->
            </div>
            <!-- Custom CSS -->
<style>
    .btn-primary {
        background-color: rgb(71, 102, 255) !important;
        border-color: rgb(89, 126, 248) !important;
        color: white !important;
        width: 50%;
        margin-left: 25%;
    }

    .btn-primary:hover {
        background-color: rgb(47, 151, 248) !important;
        border-color:rgb(47, 151, 248) !important;
    }
</style>
           <!-- /.col -->
<div class="col-md-4">
    <div class="box">
        <div class="card text-center shadow-lg" style="border-radius: 15px; overflow: hidden;">
            <div class="card-header bg-primary text-white" style="font-weight: bold; font-size: 18px;">
                Identitas Aplikasi
            </div>
            <!-- /.box-header -->
            <div class="box-body text-start p-3">
                <div class="text-center">
                    <img src="../../assets/image/book2.png" class="rounded-circle mb-3" style="width: 130px; height: 125px;">
                </div>
                <!-- Tabel Identitas -->
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 40%;">Nama Aplikasi</th>
                        <td><?= $row['nama_app']; ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td><?= $row['alamat_app']; ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?= $row['email_app']; ?></td>
                    </tr>
                    <tr>
                        <th>Nomor Telepon</th>
                        <td><?= $row['nomor_hp']; ?></td>
                    </tr>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.box -->
</div>
<!-- /.col -->

<!-- Custom CSS -->
<style>
    .card-header {
        background-color: rgb(47, 151, 248) !important;
        font-family: 'Quicksand', sans-serif;
    }

    .table th, .table td {
        vertical-align: middle;
        text-align: left;
        font-weight: bold;
        font-family: 'Quicksand', sans-serif;
    }

    .table th {
        background-color:rgb(180, 206, 227);
        color: #333;
    }

    .table td {
        background-color: rgb(157, 187, 226);
    }
</style>

    </section>
    <!-- /.content -->
</div>
<!-- jQuery 3 -->
<script src="../../assets/bower_components/jquery/dist/jquery.min.js"></script>
<script src="../../assets/dist/js/sweetalert.min.js"></script>
<!-- Pesan Berhasil Edit -->
<script>
    <?php
    if (isset($_SESSION['berhasil']) && $_SESSION['berhasil'] <> '') {
        echo "swal({
            icon: 'success',
            title: 'Berhasil',
            text: '$_SESSION[berhasil]'
        })";
    }
    $_SESSION['berhasil'] = '';
    ?>
</script>
<!-- Pesan Gagal Edit -->
<script>
    <?php
    if (isset($_SESSION['gagal']) && $_SESSION['gagal'] <> '') {
        echo "swal({
                icon: 'error',
                title: 'Gagal',
                text: '$_SESSION[gagal]'
              })";
    }
    $_SESSION['gagal'] = '';
    ?>
</script>
<!-- Swal Hapus Data -->
<script>
    $('.btn-del').on('click', function(e) {
        e.preventDefault();
        const href = $(this).attr('href')

        swal({
                icon: 'warning',
                title: 'Peringatan',
                text: 'Apakah anda yakin ingin menghapus data administrator ini ?',
                buttons: true,
                dangerMode: true,
                buttons: ['Tidak, Batalkan !', 'Iya, Hapus']
            })
            .then((willDelete) => {
                if (willDelete) {
                    document.location.href = href;
                } else {
                    swal({
                        icon: 'error',
                        title: 'Dibatalkan',
                        text: 'Data administrator tersebut tetap aman !'
                    })
                }
            });
    })
</script>