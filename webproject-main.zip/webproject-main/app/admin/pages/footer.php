<footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Perpustakaan Digital SMKN 5 Surakarta &copy; <?= date('Y'); ?></strong> - Mewujudkan Generasi Cerdas dan Berwawasan.

