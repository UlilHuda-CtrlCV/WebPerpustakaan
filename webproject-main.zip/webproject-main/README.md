# E-PERPUS
 Aplikasi perpustakaan sederhana ini dibuat menggunakan Template admin dari AdminLTE.io dan Menggunakan bahasa pemograman PHP MySQLI. <br> <br>
 Aplikasi ini bebas untuk di kembangkan lagi atau untuk bahan pembelajaran kalian bagi yang mau membuat applikasi perpustakaan, mungkin bisa mengambil contoh dari applikasi ini :)

# Akun Administrator
Username : admin
<br>
Password : admin

# Cara Instalasi
<ul>
     <li> Ekstrak arsip / file zip yang telah didownload </li>
     <li> Buka folder "e-perpus-main" </li>
     <li> Pindahkan semua file dan folder di dalam folder "e-perpus-main" ke dalam folder Localhost (htdocs) </li>
     <li> Buka XAMPP </li>
     <li> Start Module Apache dan Module MySQL </li>
     <li> Pilih aksi "Admin" pada Module MySQL untuk import database perpustakaan terlebih dahulu </li>
     <li> Jika sudah masuk ke phpMyAdmin buat sebuah basis data baru bernama "db_perpustakaan" atau bisa juga sesuai kalian masing masing </li>
     <li> JIka sudah dibuat, pilih basis data yang tadi kalian buat lalu pilih menu Import yang ada di bagian atas </li>
     <li> Pilih Choose File untuk mencari database mana yang akan di import ke basis data tersebut </li>
     <li> Jika sudah klik tombol kirim untuk mengupload database yang dipilih </li>
     <li> Selanjutnya setting file koneksi.php yang terdapat di dalam folder Config </li>
     <li> Sesuaikan dengan setinga di localhost kalian masing masing </li>
     <li> Jika menurut kalian file koneksi.php sudah sesuai dengan setingan yang kalian gunakan, Selanjutnya kalian bisa langsung masuk ke Applikasi nya :) </li>
     <li> Semoga Bermanfaat </li>
</ul>

# Terima Kasih
<ul>
    <li> AdminLTE </li>
    <li> PT. Pacifica Raya Technology </li>
    <li> Stackover Flow </li>
    <li> Google </li>
    <li> Github </li>
    <li> Malasngoding.com </li>
</ul>
